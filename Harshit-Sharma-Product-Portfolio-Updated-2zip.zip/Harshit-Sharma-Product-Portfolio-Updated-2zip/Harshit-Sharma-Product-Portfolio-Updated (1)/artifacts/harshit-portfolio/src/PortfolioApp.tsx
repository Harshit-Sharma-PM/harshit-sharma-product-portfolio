import { Link, Route, Switch, useParams } from 'wouter';
import { caseStudies } from './case-studies/registry';

function PortfolioNavigation() {
  return (
    <nav className="topbar portfolio-topbar" aria-label="Portfolio navigation">
      <div className="wrap navin">
        <Link className="brand" href="/">Harshit Sharma <span>·</span> Product Portfolio</Link>
        <div className="navlinks">
          <a href="/#about">About</a>
          <a href="/#case-studies">Case studies</a>
          <a href="https://linkedin.com/in/harshit-sharma" target="_blank" rel="noopener noreferrer">LinkedIn ↗</a>
        </div>
      </div>
    </nav>
  );
}

function PortfolioHome() {
  return (
    <>
      <PortfolioNavigation />
      <main id="main">
        <header className="wrap portfolio-hero">
          <div className="eyebrow">Product management · Digital products · AI</div>
          <h1>Harshit<br /><span className="name-last">Sharma</span></h1>
          <div className="portfolio-intro">
            <p className="portfolio-role">Associate Digital Product Manager<br />American Express<br />Digital Products · Financial Services · Operations · Fintech · GenAI · Automation</p>
            <p className="lead">I currently work as an Associate Digital Product Manager at American Express, working across digital products, financial services and customer operations. I bring 7+ years of experience building and improving customer and internal products.</p>
            <a className="text-link" href="#case-studies">Explore case studies <span aria-hidden="true">↓</span></a>
          </div>
          <div className="hero-index" aria-hidden="true"><span>01</span><i /><span>PRODUCT<br />PORTFOLIO</span></div>
        </header>

        <section id="about" className="about-section">
          <div className="wrap grid2">
            <aside className="side">
              <div className="num">About</div>
              <p>A little context on how I work and where I have worked.</p>
            </aside>
            <div className="about-main">
              <h2>My work spans product, financial services and customer operations.</h2>
              <p className="about-copy">I currently work as an Associate Digital Product Manager at American Express, where I work across digital products, financial services and customer operations. I bring 7+ years of experience across product delivery, customer operations and digital experiences.</p>
              <p className="about-copy">I contribute to CLIC, a global case-management platform, across credit-balance refunds, control management and disputes. I have owned end-to-end UAT for supported launches in France, Germany and Austria.</p>
              <div className="about-facts">
                <article className="about-fact">
                  <div className="kicker">Experience</div>
                  <h3>Product, operations, customers</h3>
                  <p><b>American Express</b> · Associate Digital Product Manager since Mar 2026; previously Product Analyst from Dec 2023</p>
                  <p><b>Concentrix</b> · Senior Representative; mentored 15 people</p>
                  <p><b>Riot Labz</b> · Customer Success Manager; 98% client retention</p>
                </article>
                <article className="about-fact">
                  <div className="kicker">Education</div>
                  <h3>Product + economics</h3>
                  <p>BITS School of Management · Program in Product Management with Generative &amp; Agentic AI</p>
                  <p>Delhi University · BA Economics</p>
                </article>
              </div>
              <div className="skill-panel">
                <div className="kicker">Skills &amp; tools</div>
                <p>Product lifecycle · Prioritization · Roadmap &amp; strategy · UAT · Agile · Requirements · GenAI · Agentic AI · RAG · Jira · Confluence · Rally · Figma</p>
              </div>
              <a className="text-link profile-link" href="https://linkedin.com/in/harshit-sharma" target="_blank" rel="noopener noreferrer">LinkedIn profile <span aria-hidden="true">↗</span></a>
            </div>
          </div>
        </section>

        <section id="case-studies" className="collection-section">
          <div className="wrap">
            <div className="collection-heading">
              <div>
                <div className="num">Selected work</div>
                <h2>Case studies</h2>
              </div>
              <p>Product thinking, made visible.</p>
            </div>
            <div className="case-list">
              {caseStudies.map((study, index) => (
                <article className="case-card" key={study.slug}>
                  <div className="case-card-art" aria-hidden="true">
                    <span className="case-art-number">0{index + 1}</span>
                    <div className="case-art-orbit"><i /><i /><i /></div>
                    <span className="case-art-word">{study.title.split(' ')[0]}</span>
                  </div>
                  <div className="case-card-copy">
                    <div className="case-meta"><span>{study.category}</span><span>Case study 0{index + 1}</span></div>
                    <h3>{study.title}</h3>
                    <p>{study.summary}</p>
                    <Link href={`/case-studies/${study.slug}`} className="case-open">Read case study <span aria-hidden="true">↗</span></Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
      <footer className="portfolio-footer">
        <div className="wrap footer-row">
          <span>Harshit Sharma · Product Portfolio</span>
          <a href="https://linkedin.com/in/harshit-sharma" target="_blank" rel="noopener noreferrer">LinkedIn ↗</a>
        </div>
      </footer>
    </>
  );
}

function DynamicCaseStudy() {
  const { slug } = useParams<{ slug: string }>();
  const study = caseStudies.find((entry) => entry.slug === slug);
  if (!study) {
    return (
      <>
        <PortfolioNavigation />
        <main className="wrap not-found">
          <div className="num">Case study not found</div>
          <h1>That page isn’t here.</h1>
          <Link className="btn primary" href="/">Back to portfolio</Link>
        </main>
      </>
    );
  }
  const StudyPage = study.page;
  return <StudyPage />;
}

export default function PortfolioApp() {
  return (
    <Switch>
      <Route path="/" component={PortfolioHome} />
      <Route path="/case-studies/:slug" component={DynamicCaseStudy} />
      <Route>
        <PortfolioNavigation />
        <main className="wrap not-found">
          <div className="num">Page not found</div>
          <h1>That page isn’t here.</h1>
          <Link className="btn primary" href="/">Back to portfolio</Link>
        </main>
      </Route>
    </Switch>
  );
}