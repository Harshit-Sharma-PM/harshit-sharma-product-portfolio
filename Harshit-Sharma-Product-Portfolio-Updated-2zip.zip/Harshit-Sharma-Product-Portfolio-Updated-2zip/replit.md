# Harshit Sharma — Product Portfolio

A React portfolio with an about section and the Saarthi AI product case study.

## Run & Operate

- Install dependencies with `pnpm install --frozen-lockfile`.
- Start the managed `artifacts/harshit-portfolio: web` workflow to view the portfolio at `/`. It runs `pnpm --filter @workspace/harshit-portfolio run dev`.
- Start `artifacts/api-server: API Server` for the Express API at `/api`. Its health endpoint is `/api/healthz`.
- The existing `artifacts/mockup-sandbox: Component Preview Server` workflow serves component previews at `/__mockup`; it is not needed to view the portfolio.
- Managed workflows supply `PORT` and `BASE_PATH`. For a standalone portfolio build from the shell, run `PORT=22529 BASE_PATH=/ pnpm --filter @workspace/harshit-portfolio run build`.
- `pnpm run typecheck` — full typecheck across all packages
- The portfolio build output is `artifacts/harshit-portfolio/dist/public`.
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- No secrets or database are required for the current portfolio or API health route. The unused database library requires `DATABASE_URL` if database-backed features are added later.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/harshit-portfolio/src/PortfolioApp.tsx` — portfolio homepage and routes.
- `artifacts/harshit-portfolio/src/App.tsx` — Saarthi AI case study.
- `artifacts/harshit-portfolio/src/case-studies/registry.ts` — case-study entries.
- `artifacts/harshit-portfolio/src/index.css` — portfolio styles.
- `artifacts/api-server/src/routes/` — Express API routes.
- `artifacts/mockup-sandbox/` — existing component-preview sandbox.
- `lib/` — shared API and database packages.
- `Harshit-Sharma-Product-Portfolio-Updated (1)/` — retained imported source copy; active workflows use the root workspace.

## Architecture decisions

Import setup preserves the existing stack, structure, content, and design.

## Product

Visitors can read the professional profile, browse case studies, open `/case-studies/saarthi-ai`, and follow the LinkedIn and prototype links.

## User preferences

The import setup request was to get the existing portfolio running on Replit.

## Gotchas

- Vite requires `PORT` even for a production build; use the managed workflow or the explicit shell build command above.
- Use pnpm rather than npm or yarn; the project enforces this during installation.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
